# The "glue" — connect payments to your email list

This Cloudflare Worker is the one small piece of live code in the whole system.
It listens for Lemon Squeezy subscription events and adds each paying reader to
your MailerLite list **with the language they chose**, so the right translated
edition goes to the right person. On cancellation it marks them unsubscribed.

It's free to run (Cloudflare's free Workers tier is generous) and you set it up
once.

## One-time setup (~15 minutes)

**A. Deploy the Worker**
```bash
cd glue
npx wrangler login          # opens your browser
npx wrangler deploy         # prints your Worker URL, e.g. https://arts-wire-glue.<you>.workers.dev
```

**B. MailerLite**
1. Create a free MailerLite account.
2. Add a **custom field** named `language` (type: text). The sender uses it.
3. (Optional) Create a **group** for subscribers; copy its ID into
   `MAILERLITE_GROUP_ID` in `wrangler.toml`, then `npx wrangler deploy` again.
4. Integrations → API → create a token. Then set it as a secret:
   ```bash
   npx wrangler secret put MAILERLITE_API_KEY
   ```

**C. Lemon Squeezy**
1. Create your products (Supporter = $12/year, Patron = $120/year).
2. Settings → Webhooks → **Add webhook**:
   - URL: your Worker URL from step A
   - Events: `subscription_created`, `subscription_updated`,
     `subscription_cancelled`, `subscription_expired`
   - Copy the **signing secret** it shows, then:
     ```bash
     npx wrangler secret put LS_WEBHOOK_SECRET
     ```
3. In your checkout / `subscribe.html`, the reader's language is passed as
   custom data `lang` (already wired in `subscribe.html`).

**D. Test it**
Use Lemon Squeezy's "Send test" on the webhook, or make a real $1 purchase.
Check MailerLite — the subscriber should appear with `language` set.

## How the language flows
`subscribe.html` (reader picks language) → Lemon Squeezy checkout (carries
`lang`) → this Worker (reads `meta.custom_data.lang`) → MailerLite (saves it in
the `language` field) → your daily send picks the matching translated edition.

## Switching to Paddle
The Worker has notes at the bottom of `worker.js` for adapting the signature
check, event names, and email/custom-data paths to Paddle.
